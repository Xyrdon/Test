package com.xyrdon.framecontrol

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private companion object {
        const val SETTING_KEY = "gamecube_frame_interpolation_for_sr"
        const val ON_VALUE = "1:1:0:60:120"
        const val OFF_VALUE = "0:-1:0:0:0"
    }

    private lateinit var toggleButton: Button
    private lateinit var modeText: TextView
    private lateinit var rawValueText: TextView
    private lateinit var feedbackText: TextView
    private lateinit var overlaySwitch: Switch
    private lateinit var monitorStatus: TextView
    private lateinit var permissionBox: View
    private var lastSetting: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val statusPoll = object : Runnable {
        override fun run() {
            if (::overlaySwitch.isInitialized) refreshMonitorStatus()
            handler.postDelayed(this, 1200L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        toggleButton = findViewById(R.id.toggleButton)
        modeText = findViewById(R.id.modeText)
        rawValueText = findViewById(R.id.rawValueText)
        feedbackText = findViewById(R.id.feedbackText)
        overlaySwitch = findViewById(R.id.overlaySwitch)
        monitorStatus = findViewById(R.id.monitorStatus)
        permissionBox = findViewById(R.id.permissionBox)
        toggleButton.setOnClickListener { toggleInterpolation() }
        overlaySwitch.setOnClickListener { toggleOverlay() }
        findViewById<Button>(R.id.grantButton).setOnClickListener { openWriteSettings() }
        refreshInterpolation()
        refreshMonitorStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::modeText.isInitialized) refreshInterpolation()
        handler.removeCallbacks(statusPoll)
        handler.post(statusPoll)
    }

    override fun onPause() {
        handler.removeCallbacks(statusPoll)
        super.onPause()
    }

    private fun canWrite(): Boolean = try {
        Settings.System.canWrite(this)
    } catch (_: Exception) { false }

    private fun refreshInterpolation() {
        val allowed = canWrite()
        permissionBox.visibility = if (allowed) View.GONE else View.VISIBLE
        toggleButton.isEnabled = allowed
        toggleButton.alpha = if (allowed) 1f else .5f
        try {
            lastSetting = Settings.System.getString(contentResolver, SETTING_KEY)
            rawValueText.text = lastSetting ?: "Параметр пока отсутствует"
            when (lastSetting) {
                ON_VALUE -> {
                    modeText.text = "РЕЖИМ ВКЛЮЧЁН"
                    toggleButton.text = "Выключить 120 FPS"
                }
                OFF_VALUE -> {
                    modeText.text = "РЕЖИМ ВЫКЛЮЧЕН"
                    toggleButton.text = "Включить 120 FPS"
                }
                else -> {
                    modeText.text = "НЕИЗВЕСТНЫЙ РЕЖИМ"
                    toggleButton.text = "Включить 120 FPS"
                }
            }
        } catch (error: Exception) {
            lastSetting = null
            modeText.text = "ОШИБКА ЧТЕНИЯ"
            toggleButton.isEnabled = false
            feedbackText.text = error.message ?: "Не удалось прочитать системный параметр"
        }
    }

    private fun toggleInterpolation() {
        if (!canWrite()) { openWriteSettings(); return }
        val desired = if (lastSetting == ON_VALUE) OFF_VALUE else ON_VALUE
        try {
            val wrote = Settings.System.putString(contentResolver, SETTING_KEY, desired)
            refreshInterpolation()
            feedbackText.text = if (wrote && lastSetting == desired) {
                "Параметр сохранён и проверен."
            } else {
                "Система не подтвердила запись."
            }
        } catch (error: Exception) {
            feedbackText.text = "Ошибка записи: ${error.message ?: error.javaClass.simpleName}"
            refreshInterpolation()
        }
    }

    private fun refreshMonitorStatus() {
        val running = FpsOverlayService.isActive
        overlaySwitch.isChecked = running
        monitorStatus.text = if (running) "Счётчик поверх приложений включён" else "Счётчик выключен"
    }

    private fun toggleOverlay() {
        if (FpsOverlayService.isActive) {
            stopService(Intent(this, FpsOverlayService::class.java))
            handler.postDelayed({ refreshMonitorStatus() }, 250L)
            return
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            overlaySwitch.isChecked = false
            Toast.makeText(this, "Разреши отображение поверх других приложений, затем нажми ON", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            }
            return
        }
        try {
            val start = Intent(this, FpsOverlayService::class.java).setAction(FpsOverlayService.ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(start) else startService(start)
            feedbackText.text = "Счётчик запускается. Запись экрана не требуется."
            handler.postDelayed({ refreshMonitorStatus() }, 500L)
        } catch (error: Exception) {
            overlaySwitch.isChecked = false
            feedbackText.text = "Не удалось запустить счётчик: ${error.message ?: error.javaClass.simpleName}"
        }
    }

    private fun openWriteSettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        } catch (_: ActivityNotFoundException) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS))
        }
    }
}
