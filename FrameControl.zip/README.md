# Frame Control 2.3.5 · DOT

Native Kotlin Android utility for OriginOS: `60 / 120 / 144 FPS` interpolation controls and floating FPS indicator.

## What's new in 2.3.5

### OriginOS small window / Android multi-window support

- `MainActivity` declares `android:resizeableActivity="true"` to explicitly support resizing and multi-window.
- Main UI is now inside a `fillViewport` `ScrollView`. On short/narrow windows it switches to compact dimensions, shrinking the central power circle, spacing and labels. The screen scrolls if an OEM's window becomes too small.
- This does **not** create a separate always-on-top overlay for the whole app. Open the app as a *system small window* through OriginOS's multitasking controls / smart sidebar if OriginOS allows that app. The final availability is controlled by the phone's firmware.
- `Picture-in-picture` was deliberately not enabled (it is designed for media and does not provide a usable interactive mini-app).

### Animated FPS Monitor switch

- `AnimatedFpsSwitch.kt` is a custom lightweight native view with a smoothly sliding circular knob, color transition, a tiny on/off glyph, and subtle pop motion.
- The monitor subtitle fades/slides between ON/OFF states, while the entire monitor panel retains touch feedback.
- The switch only animates for approximately 285 ms on state change; no background animation loop.
- As before, the switch controls `FpsOverlayService`, not the device's interpolation mode.

## System settings (unchanged)

| Selection | Value for `Settings.System` key `gamecube_frame_interpolation_for_sr` |
| --- | --- |
| 60 FPS | `1:1:0:30:60` |
| 120 FPS | `1:1:0:60:120` |
| 144 FPS | `1:1:0:72:144` |
| OFF | `0:-1:0:0:0` |

The 30→60 interpolation value follows a presumed setting format, and operation depends on the OriginOS firmware. The FPS overlay uses Android Choreographer callbacks in this utility's process; it does **not** reliably measure real game frame rate.

## GitHub build

Keep the existing workflow `.github/workflows/build-apk.yml` in the GitHub repository. For updates, replace only the root-level `FrameControl.zip` with the new archive and run the same GitHub Actions workflow (or allow push-triggered build). The ZIP contains the Kotlin project in its root; it also contains a backup copy of the workflow but the external YAML need not be changed.

- Application ID: `com.xyrdon.framecontrol` (same as previous releases)
- minSdk: `26`, targetSdk: `22` (unchanged from the previously working build)
- versionCode: `12`
- versionName: `2.3.5`
- Settings write permission and floating-overlay permission unchanged
- Same launcher icon, all FPS modes and FPS overlay service unchanged

## Testing notes

This release's source files, resource references, archive structure, and XML are checked. It has **not been compiled or run on OriginOS** here. To verify small-window compatibility use the system's small-window UI and test the FPS switch / all three modes on the device. Android's policy for legacy targetSdk apps and CI debug signing keys can affect install/upgrade separately.
