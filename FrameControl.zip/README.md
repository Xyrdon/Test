# Frame Control 2.4.0 · DOT

Minimal native Kotlin Android utility for iQOO / OriginOS. Keeps the existing AMOLED-dark DOT appearance, haptics, animation, original app icon and existing system-setting write method. No Shizuku, root, or networking.

## Changes in 2.4.0

- Removed the **60 FPS button**. Only **120 FPS** and **144 FPS** remain on the main screen. The old 60 FPS setting is still recognized so it can be disabled safely, but it is not selectable anymore.
- Added an **Auto-off** panel with **Off / 15 min / 30 min / 1 h / 2 h**. The selected duration is remembered. If interpolation is already ON when a time is chosen, a countdown starts immediately; otherwise it starts at the next activation. Switching FPS while ON restarts the countdown. A manual OFF cancels the pending timer without erasing the preference. The timer uses `AlarmManager`, not a permanently running background service; a reboot receiver attempts to restore pending alarms. Timer delivery can be delayed by Android power-saving or OEM background restrictions.
- Added **one Quick Settings tile** using `TileService`: tap cycles **120 FPS ↔ 144 FPS** (when OFF, first tap enables 120 FPS). Long-pressing a tile may open the app depending on OriginOS. To enable: open the notification shade, enter the tile editor, and add **Frame Control**, if exposed by OriginOS. Tile availability and presentation are subject to the system UI.
- Added **launcher long-press shortcuts** for 120 FPS and 144 FPS. The chosen shortcut opens Frame Control and attempts to activate the specified mode; if the system permission is missing, it prompts the user to grant it. Whether the shortcuts show is up to the OriginOS launcher.
- Made the **floating FPS indicator smaller and translucent**, using 12sp text and a black background with alpha 168/255. The monitor remains draggable. It still measures this app's Choreographer callback cadence; **it is not an accurate in-game FPS counter**.

## System values

`Settings.System["gamecube_frame_interpolation_for_sr"]`:

| Mode | Value |
|---|---|
| 120 FPS | `1:1:0:60:120` |
| 144 FPS | `1:1:0:72:144` |
| OFF | `0:-1:0:0:0` |

## Compatibility and building

- Android app ID: `com.xyrdon.framecontrol` (unchanged)
- `minSdk = 26`, **`targetSdk = 22`** (unchanged, preserves previously working legacy compatibility)
- `versionCode = 13`, `versionName = "2.4.0"`
- Source ZIP name for GitHub Actions: **`FrameControl.zip`**. Replace only the ZIP at the repository root. The existing `.github/workflows/build-apk.yml` should remain untouched. The archive also contains a project-local copy of the original workflow for reference.
- Keep using **Actions → Run workflow** if push automation does not trigger.

## Testing checklist

1. Check 120 and 144 FPS activation, readback and manual OFF; make sure no 60 FPS button exists.
2. Enable a 15-minute auto-off test and verify that the system setting returns to OFF after the interval; do not expect second-level precision, especially under aggressive battery optimization.
3. Add the Frame Control Quick Settings tile from the tile editor (if OriginOS exposes it) and tap to switch 120/144; test whether WRITE_SETTINGS permission remains granted.
4. Long-press the app icon and select the 120 or 144 shortcut (if your launcher supports app shortcuts).
5. Enable the FPS overlay and check its new size, background alpha and dragging behavior.

**Build status:** source and Android resource/XML structure verified, but APK was not compiled or tested on an actual iQOO/OriginOS device in this environment.
