# Frame Control 2.3.4 · DOT (60 / 120 / 144 FPS)

Native Kotlin Android app for OriginOS. Same `applicationId`, system-setting logic and Choreographer overlay service as DOT V2.2.

## Launcher icon fix

- Adaptive launcher icons (`mipmap-anydpi-v26`) replace the old single image.
- The original graphic had a rounded-square border inside the PNG, which OriginOS masked a second time, leaving a heavy dark rim. This version has a full-bleed deep-green background and a centered mint logo; Android applies the launcher shape just once.
- Legacy density mipmaps are also provided.
- Kept the corrected 144 FPS Settings.System value, and added a 30→60 FPS option; no change to the app ID, haptics, icon, or Choreographer service.

## Controls

- **Large circle**: toggles interpolation. The target is whichever FPS mode is selected.
- **60 FPS / 120 FPS / 144 FPS**: choose the value. While interpolation is **ON**, the change is written immediately; while **OFF**, the selection is remembered until the large circle is pressed.
- **FPS Monitor**: starts/stops the same draggable Choreographer FPS overlay used in V2.2.
- Each of the five touch surfaces gently presses to ~95–97.5% scale on finger-down and returns on release; Android's built-in haptic feedback fires when clicked (subject to the phone's haptic settings).

## System values

| State | `Settings.System` value |
| --- | --- |
| 60 FPS | `1:1:0:30:60` |
| 120 FPS | `1:1:0:60:120` |
| 144 FPS | `1:1:0:72:144` |
| OFF | `0:-1:0:0:0` |

The key is `gamecube_frame_interpolation_for_sr`. The new 30→60 FPS interpolation value follows the expected parameter pattern, but it has **not yet been verified on the target device**. Updating the system setting does not guarantee the game/firmware displays the requested number of frames.

## Permissions

- Modify system settings (`WRITE_SETTINGS`) for writing the interpolation value.
- Display over other apps (`SYSTEM_ALERT_WINDOW`) and a foreground service for the floating counter.
- Native `performHapticFeedback` does **not** require the `VIBRATE` permission and respects system vibration preferences.
- No capture screen, Shizuku or root required.

**Note:** Choreographer tracks callbacks in the overlay's own process, not necessarily a game's rendered FPS.

## Build on GitHub

One-time setup: put `build-apk.yml` from this release in `.github/workflows/build-apk.yml`. Future updates: keep that YAML and replace only `FrameControl.zip` in repository root. Keep `versionName` numeric (e.g. `2.3.4`) and increase `versionCode` in new releases.

Upload the exact file `FrameControl.zip` to the repository root and use the standalone workflow at `.github/workflows/build-apk.yml`. It unpacks the same fixed filename on every build, so future releases only require replacing `FrameControl.zip`. A push that updates this archive triggers the workflow automatically. The ZIP also includes the Kotlin project and a copy of the workflow.

`targetSdk = 22` is intentionally unchanged for compatibility with the user's earlier working installation; modern Android may block installation/update of legacy-targeted APKs. Each separate CI runner can also create a new debug signing key, which may prevent in-place upgrades. Keep your working APK in case the test build can't be installed.

## Version

- applicationId: `com.xyrdon.framecontrol`
- versionCode: `11`
- versionName: `2.3.4`
- minSdk: `26`
- targetSdk: `22`
