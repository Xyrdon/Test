# Frame Control 2.4.3 · DOT

A compact Kotlin Android utility for OriginOS / iQOO with a dark DOT UI. It writes the device-specific `Settings.System` entry `gamecube_frame_interpolation_for_sr` after user authorization. The app is not a general-purpose FPS unlocker: actual frame interpolation depends on OriginOS and the game.

## Changes in 2.4.3

- Restored the **60 FPS** mode button; all three buttons are evenly spaced: **60 / 120 / 144 FPS**.
- Restored the 30 → 60 interpolation value `1:1:0:30:60` as a selectable option, including system readback and last-selected-mode persistence.
- The Quick Settings tile continues to toggle the last-selected mode ON/OFF, now including 60 FPS.
- Auto-off now also recognizes 60 FPS as a valid active mode, so the timer can be started and enforced for it.
- Preserved the current DOT design, expandable timer card, animated FPS monitor switch, floating monitor, haptics, app icon, and long-press launcher shortcuts for 120/144 FPS.
- `versionCode = 16`, `versionName = "2.4.3"`; the package name and `targetSdk = 22` are unchanged.

## System values

| Button | Value | Meaning |
|---|---|---|
| 60 FPS | `1:1:0:30:60` | Requested interpolation 30 → 60 |
| 120 FPS | `1:1:0:60:120` | Requested interpolation 60 → 120 |
| 144 FPS | `1:1:0:72:144` | Requested interpolation 72 → 144 |
| OFF | `0:-1:0:0:0` | Interpolation disabled |

## Install and build

Replace **only** the file `FrameControl.zip` at the root of the GitHub repository. Your existing `.github/workflows/build-apk.yml` remains unchanged. If Actions does not build automatically, select **Actions → Build Frame Control → Run workflow**.

The archive itself contains the project and a local reference copy of the workflow. Android app ID remains `com.xyrdon.framecontrol` so the newly built APK can update the previous package when signing keys are compatible.

## Recommended tests on OriginOS

1. Turn on each mode and verify that the system entry matches the table. Verify the center circle shows the selected mode.
2. With 60 FPS selected, turn the mode OFF in the app; then press the Quick Settings tile once to turn 60 ON and again to turn it OFF.
3. With 60 FPS active, set a 15-minute auto-off; verify the countdown notification and whether the setting returns to OFF. Check 120/144 as well.
4. Verify that the floating FPS monitor, animations, and 120/144 launcher shortcuts still work.

**Caveats:** The value `1:1:0:30:60` follows the previously chosen OriginOS parameter pattern; device-specific support must be confirmed on the real phone. An Android timer can still be delayed when OriginOS restricts background execution. The overlay's `Choreographer` callback rate is not an authoritative measurement of in-game frames.

**Verification:** Static source checks, XML validation, and ZIP integrity can be done here. Compiling the Android APK and testing OriginOS behavior require the GitHub build and device test.
