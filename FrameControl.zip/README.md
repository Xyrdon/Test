# Frame Control 2.4.1 · DOT

Minimal native Kotlin Android utility for iQOO / OriginOS. Keeps the existing AMOLED-dark DOT appearance, haptics, animation, original app icon and existing system-setting write method. No Shizuku, root, or networking.

## Changes in 2.4.1

- **Quick Settings tile is now an ON/OFF switch:** when OFF, tapping enables the **last selected** 120 or 144 FPS value; when ON, tapping switches to OFF. Changes made with app buttons or launcher shortcuts remain synchronized. Press again to disable without opening the app. A `TileService` active tile declaration improves state synchronization on supported Android UI; OriginOS may vary.
- **Collapsed Auto-off card:** now a single tidy row with timer icon, state description, selected interval and animated chevron. Tap the card to expand Off / 15 min / 30 min / 1 h / 2 h, select an interval to collapse automatically. Timer behavior and alarm mechanism unchanged.
- **Cleaner vertical layout:** no large gap between 120/144 FPS controls and the auto-off card. Spare vertical space is distributed above and below the controls; the ScrollView still supports narrow floating windows.
- Preserved original power circle, theme, icon, overlay design, two-mode shortcuts, stored FPS preference, native settings write code, targetSdk 22 and package name.
- `versionCode = 14`, `versionName = "2.4.1"`.

**Test:** select 144 FPS on the main screen; switch it OFF; tap the Quick Settings tile to enable 144, tap again to disable. Repeat at 120. Check timer expansion and selection. Timer exact triggering can be delayed by OriginOS background optimization.

## Previous changes in 2.4.0

- Removed the **60 FPS button**. Only **120 FPS** and **144 FPS** remain on the main screen. The old 60 FPS setting is still recognized so it can be disabled safely, but it is not selectable anymore.
- Added an **Auto-off** panel with **Off / 15 min / 30 min / 1 h / 2 h**. The selected duration is remembered. If interpolation is already ON when a time is chosen, a countdown starts immediately; otherwise it starts at the next activation. Switching FPS while ON restarts the countdown. A manual OFF cancels the pending timer without erasing the preference. The timer uses `AlarmManager`, not a permanently running background service; a reboot receiver attempts to restore pending alarms. Timer delivery can be delayed by Android power-saving or OEM background restrictions.
- Added **one Quick Settings tile** using `TileService`. Updated in 2.4.1 to toggle the last used mode ON/OFF. Long-pressing a tile may open the app depending on OriginOS. To enable: open the notification shade, enter the tile editor, and add **Frame Control**, if exposed by OriginOS. Tile availability and presentation are subject to the system UI.
- Added **launcher long-press shortcuts** for 120 FPS and 144 FPS. The chosen shortcut opens Frame Control and attempts to activate the specified mode; if the system permission is missing, it prompts the user to grant it. Whether the shortcuts show is up to the OriginOS launcher.
- Made the **floating FPS indicator smaller and translucent**, using 12sp text and a black background with alpha 168/255. The monitor remains draggable. It still measures this app's Choreographer callback cadence; **it is not an accurate in-game FPS counter**.

## System values

`Settings.System["gamecube_frame_interpolation_for_sr"]`:

| Mode | Value |
|---|---|
| 120 FPS | `1:1:0:60:120` |
| 144 FPS | `1:1:0:72:144` |
| OFF | `0:-1:0:0:0` |

## Compatibility and building

- Android app ID: `com.xyrdon.framecontrol` (unchanged)
- `minSdk = 26`, **`targetSdk = 22`** (unchanged, preserves previously working legacy compatibility)
- `versionCode = 14`, `versionName = "2.4.1"`
- Source ZIP name for GitHub Actions: **`FrameControl.zip`**. Replace only the ZIP at the repository root. The existing `.github/workflows/build-apk.yml` should remain untouched. The archive also contains a project-local copy of the original workflow for reference.
- Keep using **Actions → Run workflow** if push automation does not trigger.

## Testing checklist

1. Check 120 and 144 FPS activation, readback and manual OFF; make sure no 60 FPS button exists.
2. Enable a 15-minute auto-off test and verify that the system setting returns to OFF after the interval; do not expect second-level precision, especially under aggressive battery optimization.
3. Add the Frame Control Quick Settings tile from the tile editor (if OriginOS exposes it). Select 144 in the app and turn the mode OFF, then tap the tile to turn 144 ON and a second time to turn it OFF. Repeat with 120; test whether WRITE_SETTINGS permission remains granted.
4. Long-press the app icon and select the 120 or 144 shortcut (if your launcher supports app shortcuts).
5. Enable the FPS overlay and check its new size, background alpha and dragging behavior.

**Build status:** source and Android resource/XML structure verified, but APK was not compiled or tested on an actual iQOO/OriginOS device in this environment.
