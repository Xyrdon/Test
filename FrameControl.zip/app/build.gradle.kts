plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.xyrdon.framecontrol"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.xyrdon.framecontrol"
        minSdk = 26
        targetSdk = 22
        versionCode = 16
        versionName = "2.4.3"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
