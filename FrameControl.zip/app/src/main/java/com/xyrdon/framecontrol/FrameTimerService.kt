package com.xyrdon.framecontrol

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log

/**
 * Minimal foreground watchdog while auto-off is active. No busy loop:
 * one delayed callback at the next deadline, with AlarmManager as a backup.
 * A quiet notification lets the user see or cancel a running countdown.
 */
class FrameTimerService : Service() {
    private companion object {
        const val CHANNEL_ID = "framecontrol_auto_off_v242"
        const val NOTIFICATION_ID = 43
    }
    private val handler = Handler(Looper.getMainLooper())
    private val deadlineCheck = Runnable { enforceDeadline() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        handler.removeCallbacks(deadlineCheck)
        val deadline = FrameAutoOff.deadline(this)
        if (deadline <= 0L || FrameAutoOff.expectedMode(this) == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        try {
            promoteToForeground(deadline)
        } catch (error: Exception) {
            Log.e("FrameControl", "Auto-off foreground service failed", error)
            stopSelf(startId)
            return START_NOT_STICKY
        }
        enforceDeadline()
        return START_STICKY
    }

    private fun promoteToForeground(deadline: Long) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Frame Control · таймер", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val open = PendingIntent.getActivity(
            this, 886, Intent(this, MainActivity::class.java), flags
        )
        val cancel = PendingIntent.getBroadcast(
            this, 887,
            Intent(this, FrameAutoOffReceiver::class.java).setAction(FrameAutoOff.ACTION_CANCEL), flags
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
                      else Notification.Builder(this)
        val notification = builder
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Frame Control · автовыключение")
            .setContentText("Режим FPS отключится по таймеру")
            .setWhen(deadline)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Отменить таймер", cancel)
            .build()
        startForeground(NOTIFICATION_ID, notification)
    }

    private fun enforceDeadline() {
        val deadline = FrameAutoOff.deadline(this)
        if (deadline <= 0L) { stopSelf(); return }
        val remaining = deadline - System.currentTimeMillis()
        if (remaining <= 0L) {
            FrameAutoOff.onTimer(this)
            if (FrameAutoOff.deadline(this) <= 0L) stopSelf()
            else handler.postDelayed(deadlineCheck, 1_000L)
        } else {
            // Handler suspends with the process; the wakeup alarm covers device sleep.
            handler.postDelayed(deadlineCheck, remaining.coerceAtLeast(1L))
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(deadlineCheck)
        stopForeground(true)
        super.onDestroy()
    }
}
