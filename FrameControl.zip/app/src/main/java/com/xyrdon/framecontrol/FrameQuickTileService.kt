package com.xyrdon.framecontrol

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** One Quick Settings tile: each tap switches 120 <-> 144; if off, enables 120. */
class FrameQuickTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        if (isLocked || !FrameControlSettings.canWrite(this)) {
            openApp()
            return
        }
        val current = FrameControlSettings.read(this)
        val next = if (current == FrameControlSettings.ON_120) 144 else 120
        if (!FrameControlSettings.write(this, FrameControlSettings.valueFor(next))) {
            openApp()
        }
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val current = FrameControlSettings.read(this)
        val label = when (current) {
            FrameControlSettings.ON_120 -> "120 FPS"
            FrameControlSettings.ON_144 -> "144 FPS"
            else -> "Frame Control"
        }
        tile.label = label
        tile.state = if (FrameControlSettings.isActive(current)) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        if (Build.VERSION.SDK_INT >= 29) tile.subtitle = "120 ↔ 144 FPS"
        tile.updateTile()
    }

    private fun openApp() {
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (Build.VERSION.SDK_INT >= 34) {
            val pending = PendingIntent.getActivity(this, 975, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            startActivityAndCollapse(pending)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }
}
