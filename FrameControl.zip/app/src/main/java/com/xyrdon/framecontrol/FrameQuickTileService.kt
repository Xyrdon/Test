package com.xyrdon.framecontrol

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** One Quick Settings tile: tap enables last selected 60/120/144 mode; next tap turns it OFF. */
class FrameQuickTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        if (isLocked || !FrameControlSettings.canWrite(this)) {
            openApp()
            return
        }
        val current = FrameControlSettings.read(this)
        val target = if (FrameControlSettings.isActive(current)) {
            FrameControlSettings.OFF
        } else {
            FrameControlSettings.valueFor(FrameControlSettings.selected(this))
        }
        if (!FrameControlSettings.write(this, target)) {
            openApp()
        }
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val current = FrameControlSettings.read(this)
        val active = FrameControlSettings.isActive(current)
        // Keep a stable label while showing the current mode and next action below it.
        tile.label = "Frame Control"
        tile.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        if (Build.VERSION.SDK_INT >= 29) {
            val mode = when (current) {
                FrameControlSettings.ON_120 -> 120
                FrameControlSettings.ON_144 -> 144
                FrameControlSettings.ON_60 -> 60
                else -> FrameControlSettings.selected(this)
            }
            tile.subtitle = if (active) "$mode FPS · выкл." else "$mode FPS · вкл."
        }
        tile.updateTile()
    }

    private fun openApp() {
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (Build.VERSION.SDK_INT >= 34) {
            val pending = PendingIntent.getActivity(this, 975, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            startActivityAndCollapse(pending)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }
}
