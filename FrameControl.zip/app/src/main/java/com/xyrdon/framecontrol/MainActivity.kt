package com.xyrdon.framecontrol

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.util.TypedValue
import android.widget.ScrollView
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * DOT V2.3.5: resizable mini-window layout and animated FPS Monitor switch.
 * The target SDK, application ID and method of writing the system setting
 * stay unchanged from the working DOT V2.2 build.
 */
class MainActivity : Activity() {
    private companion object {
        const val SETTING_KEY = "gamecube_frame_interpolation_for_sr"
        const val ON_60 = "1:1:0:30:60"
        const val ON_120 = "1:1:0:60:120"
        const val ON_144 = "1:1:0:72:144"
        const val OFF_VALUE = "0:-1:0:0:0"
        const val PREFS = "frame_control_dot"
        const val PREF_SELECTED_FPS = "selected_fps"

        const val COLOR_ON = 0xFFA1F7C6.toInt()
        const val COLOR_OFF = 0xFF737C76.toInt()
        const val COLOR_MODE_ON_BG = 0xFF101D17.toInt()
        const val COLOR_MODE_OFF_BG = 0xFF111313.toInt()
    }

    private lateinit var dotCircle: FrameLayout
    private lateinit var powerIcon: ImageView
    private lateinit var circleFpsText: TextView
    private lateinit var modeLabel: TextView
    private lateinit var mode60: TextView
    private lateinit var mode120: TextView
    private lateinit var mode144: TextView
    private lateinit var fpsToggle: AnimatedFpsSwitch
    private lateinit var fpsSubtitle: TextView
    private lateinit var screenScroll: ScrollView
    private lateinit var contentRoot: LinearLayout
    private lateinit var headerTitle: TextView
    private lateinit var centerSection: LinearLayout
    private lateinit var modesRow: LinearLayout
    private var monitorUiState: Boolean? = null
    private var lastWindowWidth = -1
    private var lastWindowHeight = -1
    private lateinit var fpsPanel: LinearLayout

    private var selectedFps = 120
    private var lastSetting: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val statusPoll = object : Runnable {
        override fun run() {
            refreshMonitorStatus()
            handler.postDelayed(this, 1200L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dotCircle = findViewById(R.id.dotCircle)
        powerIcon = findViewById(R.id.powerIcon)
        circleFpsText = findViewById(R.id.circleFpsText)
        modeLabel = findViewById(R.id.modeText)
        mode60 = findViewById(R.id.select60)
        mode120 = findViewById(R.id.select120)
        mode144 = findViewById(R.id.select144)
        fpsToggle = findViewById(R.id.overlayToggle)
        fpsSubtitle = findViewById(R.id.overlaySubtitle)
        screenScroll = findViewById(R.id.screenScroll)
        contentRoot = findViewById(R.id.contentRoot)
        headerTitle = findViewById(R.id.headerTitle)
        centerSection = findViewById(R.id.centerSection)
        modesRow = findViewById(R.id.modesRow)

        // The system may resize a floating window without recreating the activity.
        screenScroll.viewTreeObserver.addOnGlobalLayoutListener {
            val width = screenScroll.width
            val height = screenScroll.height
            if (width > 0 && height > 0 &&
                (width != lastWindowWidth || height != lastWindowHeight)) {
                lastWindowWidth = width
                lastWindowHeight = height
                adaptToWindow(width, height)
            }
        }
        fpsPanel = findViewById(R.id.overlayPanel)

        val stored = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(PREF_SELECTED_FPS, 120)
        selectedFps = if (stored == 60 || stored == 120 || stored == 144) stored else 120

        pressAnimation(dotCircle, 0.952f)
        pressAnimation(mode60, 0.96f)
        pressAnimation(mode120, 0.96f)
        pressAnimation(mode144, 0.96f)
        pressAnimation(fpsPanel, 0.975f)

        dotCircle.setOnClickListener { view ->
            haptic(view)
            toggleInterpolation()
        }
        mode60.setOnClickListener { view ->
            haptic(view)
            selectMode(60)
        }
        mode120.setOnClickListener { view ->
            haptic(view)
            selectMode(120)
        }
        mode144.setOnClickListener { view ->
            haptic(view)
            selectMode(144)
        }
        fpsPanel.setOnClickListener { view ->
            haptic(view)
            toggleOverlay()
        }

        refreshInterpolation()
        refreshMonitorStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::modeLabel.isInitialized) refreshInterpolation()
        handler.removeCallbacks(statusPoll)
        handler.post(statusPoll)
    }

    override fun onPause() {
        handler.removeCallbacks(statusPoll)
        super.onPause()
    }

    // Subtle scale-down while the finger is held down, and a quick spring-like return.
    // Returning false preserves accessibility, normal click behaviour and cancellation.
    private fun pressAnimation(view: View, pressedScale: Float) {
        view.isHapticFeedbackEnabled = true
        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate()
                    .scaleX(pressedScale).scaleY(pressedScale)
                    .setDuration(85L).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate()
                    .scaleX(1f).scaleY(1f)
                    .setDuration(155L).start()
            }
            false
        }
    }

    // Uses Android's native touch haptics; no dangerous/extra permission needed.
    private fun haptic(view: View) {
        val effect = if (Build.VERSION.SDK_INT >= 30) {
            HapticFeedbackConstants.CONFIRM
        } else {
            HapticFeedbackConstants.VIRTUAL_KEY
        }
        view.performHapticFeedback(effect)
    }

    private fun dp(value: Int): Int = (resources.displayMetrics.density * value + 0.5f).toInt()

    private fun circleBackground(enabled: Boolean): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(if (enabled) COLOR_MODE_ON_BG else COLOR_MODE_OFF_BG)
        setStroke(dp(2), if (enabled) 0xFF78DCAA.toInt() else 0xFF444A47.toInt())
    }

    private fun optionBackground(chosen: Boolean): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(40).toFloat()
        setColor(if (chosen) 0xFFA1F7C6.toInt() else 0xFF151C18.toInt())
        setStroke(dp(1), if (chosen) 0xFFA1F7C6.toInt() else 0xFF303B33.toInt())
    }


    private fun canWriteSystemSettings(): Boolean = try {
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.System.canWrite(this)
    } catch (_: Exception) {
        false
    }

    private fun valueFor(fps: Int): String = when (fps) {
        60 -> ON_60
        144 -> ON_144
        else -> ON_120
    }
    private fun isInterpolationActive(value: String?): Boolean = value == ON_60 || value == ON_120 || value == ON_144

    private fun refreshInterpolation() {
        try {
            lastSetting = Settings.System.getString(contentResolver, SETTING_KEY)
            // The real system value wins over previously stored selection when already ON.
            when (lastSetting) {
                ON_60 -> storeSelectedMode(60)
                ON_120 -> storeSelectedMode(120)
                ON_144 -> storeSelectedMode(144)
            }
            val enabled = isInterpolationActive(lastSetting)
            dotCircle.background = circleBackground(enabled)
            powerIcon.imageTintList = ColorStateList.valueOf(if (enabled) COLOR_ON else COLOR_OFF)
            circleFpsText.text = "$selectedFps FPS"
            modeLabel.text = when (lastSetting) {
                ON_60, ON_120, ON_144 -> "Включено"
                OFF_VALUE, null -> "Выключено"
                else -> "Другой режим"
            }
            modeLabel.setTextColor(if (enabled) 0xFF8BCFA5.toInt() else 0xFF878D89.toInt())
            dotCircle.contentDescription = if (enabled) {
                "$selectedFps FPS включено. Нажми, чтобы выключить"
            } else {
                "$selectedFps FPS выключено. Нажми, чтобы включить"
            }
            updateSelector()
        } catch (error: Exception) {
            lastSetting = null
            dotCircle.background = circleBackground(false)
            powerIcon.imageTintList = ColorStateList.valueOf(COLOR_OFF)
            circleFpsText.text = "$selectedFps FPS"
            modeLabel.text = "Ошибка чтения"
            modeLabel.setTextColor(COLOR_OFF)
            updateSelector()
        }
    }

    private fun storeSelectedMode(value: Int) {
        selectedFps = value
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(PREF_SELECTED_FPS, value).apply()
    }

    private fun updateSelector() {
        mode60.background = optionBackground(selectedFps == 60)
        mode120.background = optionBackground(selectedFps == 120)
        mode144.background = optionBackground(selectedFps == 144)
        mode60.setTextColor(if (selectedFps == 60) 0xFF0A2114.toInt() else 0xFF9BAAA0.toInt())
        mode120.setTextColor(if (selectedFps == 120) 0xFF0A2114.toInt() else 0xFF9BAAA0.toInt())
        mode144.setTextColor(if (selectedFps == 144) 0xFF0A2114.toInt() else 0xFF9BAAA0.toInt())
        mode60.isSelected = selectedFps == 60
        mode120.isSelected = selectedFps == 120
        mode144.isSelected = selectedFps == 144
        mode60.contentDescription = "60 FPS" + if (selectedFps == 60) ", выбрано" else ", выбрать"
        mode120.contentDescription = "120 FPS" + if (selectedFps == 120) ", выбрано" else ", выбрать"
        mode144.contentDescription = "144 FPS" + if (selectedFps == 144) ", выбрано" else ", выбрать"
    }

    private fun selectMode(fps: Int) {
        if (fps == selectedFps) return
        if (isInterpolationActive(lastSetting)) {
            // When the engine is ON, switching 60/120/144 immediately writes the new value.
            writeAndVerify(valueFor(fps))
            // refreshInterpolation() reads back the real system mode, including on failure.
        } else {
            // When OFF, only remember the selection; do not activate interpolation.
            storeSelectedMode(fps)
            refreshInterpolation()
        }
    }

    private fun toggleInterpolation() {
        val target = if (isInterpolationActive(lastSetting)) OFF_VALUE else valueFor(selectedFps)
        writeAndVerify(target)
    }

    private fun writeAndVerify(target: String) {
        if (!canWriteSystemSettings()) {
            Toast.makeText(this, "Разреши изменение системных настроек", Toast.LENGTH_LONG).show()
            openWriteSettings()
            return
        }
        try {
            val accepted = Settings.System.putString(contentResolver, SETTING_KEY, target)
            refreshInterpolation()
            if (!accepted || lastSetting != target) {
                Toast.makeText(this, "Android не подтвердил изменение параметра", Toast.LENGTH_LONG).show()
            }
        } catch (error: Exception) {
            refreshInterpolation()
            Toast.makeText(this,
                "Ошибка записи: ${error.message ?: error.javaClass.simpleName}",
                Toast.LENGTH_LONG).show()
        }
    }

    private fun refreshMonitorStatus() {
        if (!::fpsToggle.isInitialized) return
        updateMonitorVisual(FpsOverlayService.isActive, animated = monitorUiState != null)
    }

    private fun updateMonitorVisual(enabled: Boolean, animated: Boolean) {
        if (monitorUiState == enabled) return
        monitorUiState = enabled
        fpsToggle.setEnabledState(enabled, animated)
        val caption = if (enabled) "Плавающий счётчик · включён" else "Плавающий счётчик · выкл."
        val textColor = if (enabled) 0xFF98D7AE.toInt() else 0xFF879B8D.toInt()
        if (animated) {
            fpsSubtitle.animate().cancel()
            fpsSubtitle.animate().alpha(0.35f).translationY(dp(3).toFloat())
                .setDuration(95L).withEndAction {
                    fpsSubtitle.text = caption
                    fpsSubtitle.setTextColor(textColor)
                    fpsSubtitle.translationY = -dp(3).toFloat()
                    fpsSubtitle.animate().alpha(1f).translationY(0f)
                        .setDuration(180L).start()
                }.start()
        } else {
            fpsSubtitle.text = caption
            fpsSubtitle.setTextColor(textColor)
            fpsSubtitle.alpha = 1f
            fpsSubtitle.translationY = 0f
        }
        fpsPanel.contentDescription = if (enabled) {
            "Счётчик FPS включён. Нажми для выключения"
        } else {
            "Счётчик FPS выключен. Нажми для включения"
        }
    }

    private fun toggleOverlay() {
        if (monitorUiState == true || FpsOverlayService.isActive) {
            stopService(Intent(this, FpsOverlayService::class.java))
            updateMonitorVisual(false, animated = true)
            handler.postDelayed({ refreshMonitorStatus() }, 300L)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши отображение поверх других приложений", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: ActivityNotFoundException) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            }
            return
        }
        try {
            val start = Intent(this, FpsOverlayService::class.java).setAction(FpsOverlayService.ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(start) else startService(start)
            updateMonitorVisual(true, animated = true)
            handler.postDelayed({ refreshMonitorStatus() }, 550L)
        } catch (error: Exception) {
            Toast.makeText(this,
                "Не удалось включить счётчик: ${error.message ?: error.javaClass.simpleName}",
                Toast.LENGTH_LONG).show()
            refreshMonitorStatus()
        }
    }

    /** Compact sizing works for OriginOS small windows and normal Android multi-window. */
    private fun adaptToWindow(widthPx: Int, heightPx: Int) {
        val density = resources.displayMetrics.density
        val widthDp = widthPx / density
        val heightDp = heightPx / density
        val compact = heightDp < 560f || widthDp < 340f
        val tiny = heightDp < 410f || widthDp < 265f
        val horizontalPadding = when {
            tiny -> 12
            compact -> 16
            else -> 24
        }
        contentRoot.setPadding(dp(horizontalPadding), 0, dp(horizontalPadding), 0)
        val circleSize = when {
            heightDp < 350f -> 102
            tiny -> 122
            compact -> 162
            else -> 210
        }.coerceAtMost((widthDp - horizontalPadding * 2f - 14f).toInt())
            .coerceAtLeast(90)
        dotCircle.layoutParams = dotCircle.layoutParams.apply {
            width = dp(circleSize)
            height = dp(circleSize)
        }
        powerIcon.layoutParams = powerIcon.layoutParams.apply {
            width = dp(if (tiny) 29 else if (compact) 36 else 44)
            height = dp(if (tiny) 29 else if (compact) 36 else 44)
        }
        circleFpsText.setTextSize(TypedValue.COMPLEX_UNIT_SP,
            if (tiny) 19f else if (compact) 24f else 29f)
        (circleFpsText.layoutParams as LinearLayout.LayoutParams).apply {
            topMargin = dp(if (tiny) 5 else if (compact) 8 else 12)
            circleFpsText.layoutParams = this
        }
        (headerTitle.layoutParams as LinearLayout.LayoutParams).apply {
            topMargin = dp(if (tiny) 8 else if (compact) 12 else 28)
            headerTitle.layoutParams = this
        }
        (modeLabel.layoutParams as LinearLayout.LayoutParams).apply {
            topMargin = dp(if (tiny) 7 else if (compact) 11 else 19)
            modeLabel.layoutParams = this
        }
        (modesRow.layoutParams as LinearLayout.LayoutParams).apply {
            topMargin = dp(if (tiny) 10 else if (compact) 14 else 22)
            modesRow.layoutParams = this
        }
        for (mode in arrayOf(mode60, mode120, mode144)) {
            mode.layoutParams = mode.layoutParams.apply {
                height = dp(if (tiny) 39 else if (compact) 45 else 50)
            }
            mode.setTextSize(TypedValue.COMPLEX_UNIT_SP,
                if (widthDp < 290f) 12f else if (compact) 13.5f else 15f)
        }
        (fpsPanel.layoutParams as LinearLayout.LayoutParams).apply {
            bottomMargin = dp(if (tiny) 9 else if (compact) 16 else 34)
            fpsPanel.layoutParams = this
        }
        fpsPanel.setPadding(dp(if (tiny) 13 else 19), dp(if (tiny) 9 else 13),
            dp(if (tiny) 10 else 13), dp(if (tiny) 9 else 13))
        centerSection.setPadding(0, dp(if (tiny) 2 else 6), 0, dp(if (tiny) 2 else 6))
    }

    private fun openWriteSettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        } catch (_: ActivityNotFoundException) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(this, "Открой разрешения приложения в настройках", Toast.LENGTH_LONG).show()
            }
        }
    }
}
