package com.xyrdon.framecontrol

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * DOT V2.3: one power circle, 120/144 selector, Choreographer FPS overlay.
 * The target SDK, application ID and method of writing the system setting
 * stay unchanged from the working DOT V2.2 build.
 */
class MainActivity : Activity() {
    private companion object {
        const val SETTING_KEY = "gamecube_frame_interpolation_for_sr"
        const val ON_120 = "1:1:0:60:120"
        const val ON_144 = "1:1:0:60:144"
        const val OFF_VALUE = "0:-1:0:0:0"
        const val PREFS = "frame_control_dot"
        const val PREF_SELECTED_FPS = "selected_fps"

        const val COLOR_ON = 0xFFA1F7C6.toInt()
        const val COLOR_OFF = 0xFF737C76.toInt()
        const val COLOR_MODE_ON_BG = 0xFF101D17.toInt()
        const val COLOR_MODE_OFF_BG = 0xFF111313.toInt()
    }

    private lateinit var dotCircle: FrameLayout
    private lateinit var powerIcon: ImageView
    private lateinit var circleFpsText: TextView
    private lateinit var modeLabel: TextView
    private lateinit var mode120: TextView
    private lateinit var mode144: TextView
    private lateinit var fpsToggle: TextView
    private lateinit var fpsPanel: LinearLayout

    private var selectedFps = 120
    private var lastSetting: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val statusPoll = object : Runnable {
        override fun run() {
            refreshMonitorStatus()
            handler.postDelayed(this, 1200L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dotCircle = findViewById(R.id.dotCircle)
        powerIcon = findViewById(R.id.powerIcon)
        circleFpsText = findViewById(R.id.circleFpsText)
        modeLabel = findViewById(R.id.modeText)
        mode120 = findViewById(R.id.select120)
        mode144 = findViewById(R.id.select144)
        fpsToggle = findViewById(R.id.overlayToggle)
        fpsPanel = findViewById(R.id.overlayPanel)

        val stored = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(PREF_SELECTED_FPS, 120)
        selectedFps = if (stored == 144) 144 else 120

        pressAnimation(dotCircle, 0.952f)
        pressAnimation(mode120, 0.96f)
        pressAnimation(mode144, 0.96f)
        pressAnimation(fpsPanel, 0.975f)

        dotCircle.setOnClickListener { view ->
            haptic(view)
            toggleInterpolation()
        }
        mode120.setOnClickListener { view ->
            haptic(view)
            selectMode(120)
        }
        mode144.setOnClickListener { view ->
            haptic(view)
            selectMode(144)
        }
        fpsPanel.setOnClickListener { view ->
            haptic(view)
            toggleOverlay()
        }

        refreshInterpolation()
        refreshMonitorStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::modeLabel.isInitialized) refreshInterpolation()
        handler.removeCallbacks(statusPoll)
        handler.post(statusPoll)
    }

    override fun onPause() {
        handler.removeCallbacks(statusPoll)
        super.onPause()
    }

    // Subtle scale-down while the finger is held down, and a quick spring-like return.
    // Returning false preserves accessibility, normal click behaviour and cancellation.
    private fun pressAnimation(view: View, pressedScale: Float) {
        view.isHapticFeedbackEnabled = true
        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate()
                    .scaleX(pressedScale).scaleY(pressedScale)
                    .setDuration(85L).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate()
                    .scaleX(1f).scaleY(1f)
                    .setDuration(155L).start()
            }
            false
        }
    }

    // Uses Android's native touch haptics; no dangerous/extra permission needed.
    private fun haptic(view: View) {
        val effect = if (Build.VERSION.SDK_INT >= 30) {
            HapticFeedbackConstants.CONFIRM
        } else {
            HapticFeedbackConstants.VIRTUAL_KEY
        }
        view.performHapticFeedback(effect)
    }

    private fun dp(value: Int): Int = (resources.displayMetrics.density * value + 0.5f).toInt()

    private fun circleBackground(enabled: Boolean): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(if (enabled) COLOR_MODE_ON_BG else COLOR_MODE_OFF_BG)
        setStroke(dp(2), if (enabled) 0xFF78DCAA.toInt() else 0xFF444A47.toInt())
    }

    private fun optionBackground(chosen: Boolean): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(40).toFloat()
        setColor(if (chosen) 0xFFA1F7C6.toInt() else 0xFF151C18.toInt())
        setStroke(dp(1), if (chosen) 0xFFA1F7C6.toInt() else 0xFF303B33.toInt())
    }

    private fun toggleBackground(enabled: Boolean): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(30).toFloat()
        setColor(if (enabled) 0xFF8DE7B0.toInt() else 0xFF303C34.toInt())
    }

    private fun canWriteSystemSettings(): Boolean = try {
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.System.canWrite(this)
    } catch (_: Exception) {
        false
    }

    private fun valueFor(fps: Int): String = if (fps == 144) ON_144 else ON_120
    private fun isInterpolationActive(value: String?): Boolean = value == ON_120 || value == ON_144

    private fun refreshInterpolation() {
        try {
            lastSetting = Settings.System.getString(contentResolver, SETTING_KEY)
            // The real system value wins over previously stored selection when already ON.
            when (lastSetting) {
                ON_120 -> storeSelectedMode(120)
                ON_144 -> storeSelectedMode(144)
            }
            val enabled = isInterpolationActive(lastSetting)
            dotCircle.background = circleBackground(enabled)
            powerIcon.imageTintList = ColorStateList.valueOf(if (enabled) COLOR_ON else COLOR_OFF)
            circleFpsText.text = "$selectedFps FPS"
            modeLabel.text = when (lastSetting) {
                ON_120, ON_144 -> "Включено"
                OFF_VALUE, null -> "Выключено"
                else -> "Другой режим"
            }
            modeLabel.setTextColor(if (enabled) 0xFF8BCFA5.toInt() else 0xFF878D89.toInt())
            dotCircle.contentDescription = if (enabled) {
                "$selectedFps FPS включено. Нажми, чтобы выключить"
            } else {
                "$selectedFps FPS выключено. Нажми, чтобы включить"
            }
            updateSelector()
        } catch (error: Exception) {
            lastSetting = null
            dotCircle.background = circleBackground(false)
            powerIcon.imageTintList = ColorStateList.valueOf(COLOR_OFF)
            circleFpsText.text = "$selectedFps FPS"
            modeLabel.text = "Ошибка чтения"
            modeLabel.setTextColor(COLOR_OFF)
            updateSelector()
        }
    }

    private fun storeSelectedMode(value: Int) {
        selectedFps = value
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(PREF_SELECTED_FPS, value).apply()
    }

    private fun updateSelector() {
        mode120.background = optionBackground(selectedFps == 120)
        mode144.background = optionBackground(selectedFps == 144)
        mode120.setTextColor(if (selectedFps == 120) 0xFF0A2114.toInt() else 0xFF9BAAA0.toInt())
        mode144.setTextColor(if (selectedFps == 144) 0xFF0A2114.toInt() else 0xFF9BAAA0.toInt())
        mode120.isSelected = selectedFps == 120
        mode144.isSelected = selectedFps == 144
        mode120.contentDescription = "120 FPS" + if (selectedFps == 120) ", выбрано" else ", выбрать"
        mode144.contentDescription = "144 FPS" + if (selectedFps == 144) ", выбрано" else ", выбрать"
    }

    private fun selectMode(fps: Int) {
        if (fps == selectedFps) return
        if (isInterpolationActive(lastSetting)) {
            // When the engine is ON, switching 120/144 immediately writes the new value.
            writeAndVerify(valueFor(fps))
            // refreshInterpolation() reads back the real system mode, including on failure.
        } else {
            // When OFF, only remember the selection; do not activate interpolation.
            storeSelectedMode(fps)
            refreshInterpolation()
        }
    }

    private fun toggleInterpolation() {
        val target = if (isInterpolationActive(lastSetting)) OFF_VALUE else valueFor(selectedFps)
        writeAndVerify(target)
    }

    private fun writeAndVerify(target: String) {
        if (!canWriteSystemSettings()) {
            Toast.makeText(this, "Разреши изменение системных настроек", Toast.LENGTH_LONG).show()
            openWriteSettings()
            return
        }
        try {
            val accepted = Settings.System.putString(contentResolver, SETTING_KEY, target)
            refreshInterpolation()
            if (!accepted || lastSetting != target) {
                Toast.makeText(this, "Android не подтвердил изменение параметра", Toast.LENGTH_LONG).show()
            }
        } catch (error: Exception) {
            refreshInterpolation()
            Toast.makeText(this,
                "Ошибка записи: ${error.message ?: error.javaClass.simpleName}",
                Toast.LENGTH_LONG).show()
        }
    }

    private fun refreshMonitorStatus() {
        if (!::fpsToggle.isInitialized) return
        val enabled = FpsOverlayService.isActive
        fpsToggle.text = if (enabled) "ON" else "OFF"
        fpsToggle.setTextColor(if (enabled) 0xFF092112.toInt() else 0xFFC0C8C2.toInt())
        fpsToggle.background = toggleBackground(enabled)
        fpsPanel.contentDescription = if (enabled) {
            "Счётчик FPS включён. Нажми для выключения"
        } else {
            "Счётчик FPS выключен. Нажми для включения"
        }
    }

    private fun toggleOverlay() {
        if (FpsOverlayService.isActive) {
            stopService(Intent(this, FpsOverlayService::class.java))
            handler.postDelayed({ refreshMonitorStatus() }, 250L)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши отображение поверх других приложений", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: ActivityNotFoundException) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            }
            return
        }
        try {
            val start = Intent(this, FpsOverlayService::class.java).setAction(FpsOverlayService.ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(start) else startService(start)
            handler.postDelayed({ refreshMonitorStatus() }, 500L)
        } catch (error: Exception) {
            Toast.makeText(this,
                "Не удалось включить счётчик: ${error.message ?: error.javaClass.simpleName}",
                Toast.LENGTH_LONG).show()
            refreshMonitorStatus()
        }
    }

    private fun openWriteSettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        } catch (_: ActivityNotFoundException) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(this, "Открой разрешения приложения в настройках", Toast.LENGTH_LONG).show()
            }
        }
    }
}
