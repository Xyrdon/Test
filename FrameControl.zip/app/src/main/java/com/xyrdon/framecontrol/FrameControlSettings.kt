package com.xyrdon.framecontrol

import android.content.Context
import android.content.ComponentName
import android.service.quicksettings.TileService
import android.os.Build
import android.provider.Settings

/** Centralizes writes so UI, shortcuts and quick settings share the same timer behavior. */
object FrameControlSettings {
    const val KEY = "gamecube_frame_interpolation_for_sr"
    const val ON_60 = "1:1:0:30:60" // 30 -> 60 FPS interpolation
    const val ON_120 = "1:1:0:60:120"
    const val ON_144 = "1:1:0:72:144"
    const val OFF = "0:-1:0:0:0"
    const val PREFS = "frame_control_dot"
    const val PREF_SELECTED = "selected_fps"

    fun read(context: Context): String? = try {
        Settings.System.getString(context.contentResolver, KEY)
    } catch (_: Exception) { null }

    fun isActive(value: String?): Boolean = value == ON_60 || value == ON_120 || value == ON_144

    fun canWrite(context: Context): Boolean = try {
        Build.VERSION.SDK_INT < 23 || Settings.System.canWrite(context)
    } catch (_: Exception) { false }

    fun selected(context: Context): Int {
        val fps = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(PREF_SELECTED, 120)
        return if (fps == 60 || fps == 120 || fps == 144) fps else 120
    }

    fun remember(context: Context, fps: Int) {
        if (fps != 60 && fps != 120 && fps != 144) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putInt(PREF_SELECTED, fps).apply()
    }

    fun valueFor(fps: Int): String = when (fps) {
        60 -> ON_60
        144 -> ON_144
        else -> ON_120
    }

    /** Refreshes a previously added tile; OriginOS can still limit tile availability. */
    fun updateQuickTile(context: Context) {
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                TileService.requestListeningState(
                    context, ComponentName(context, FrameQuickTileService::class.java)
                )
            } catch (_: Exception) { /* QS tile may not exist on this launcher */ }
        }
    }

    /** True only if the write was accepted AND readback matches. */
    fun write(context: Context, value: String): Boolean {
        if (!canWrite(context)) return false
        return try {
            val success = Settings.System.putString(context.contentResolver, KEY, value)
            val verified = success && read(context) == value
            if (verified) {
                when (value) {
                    ON_60 -> remember(context, 60)
                    ON_120 -> remember(context, 120)
                    ON_144 -> remember(context, 144)
                }
                FrameAutoOff.onConfirmedWrite(context, value)
                updateQuickTile(context)
            }
            verified
        } catch (_: Exception) { false }
    }
}
