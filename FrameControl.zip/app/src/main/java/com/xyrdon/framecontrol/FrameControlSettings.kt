package com.xyrdon.framecontrol

import android.content.Context
import android.os.Build
import android.provider.Settings

/** Centralizes writes so UI, shortcuts and quick settings share the same timer behavior. */
object FrameControlSettings {
    const val KEY = "gamecube_frame_interpolation_for_sr"
    const val ON_60_OLD = "1:1:0:30:60" // Recognize an older installed mode; no new 60 FPS button.
    const val ON_120 = "1:1:0:60:120"
    const val ON_144 = "1:1:0:72:144"
    const val OFF = "0:-1:0:0:0"
    const val PREFS = "frame_control_dot"
    const val PREF_SELECTED = "selected_fps"

    fun read(context: Context): String? = try {
        Settings.System.getString(context.contentResolver, KEY)
    } catch (_: Exception) { null }

    fun isActive(value: String?): Boolean = value == ON_60_OLD || value == ON_120 || value == ON_144

    fun canWrite(context: Context): Boolean = try {
        Build.VERSION.SDK_INT < 23 || Settings.System.canWrite(context)
    } catch (_: Exception) { false }

    fun selected(context: Context): Int {
        val fps = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(PREF_SELECTED, 120)
        return if (fps == 144) 144 else 120
    }

    fun remember(context: Context, fps: Int) {
        if (fps != 120 && fps != 144) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putInt(PREF_SELECTED, fps).apply()
    }

    fun valueFor(fps: Int): String = if (fps == 144) ON_144 else ON_120

    /** True only if the write was accepted AND readback matches. */
    fun write(context: Context, value: String): Boolean {
        if (!canWrite(context)) return false
        return try {
            val success = Settings.System.putString(context.contentResolver, KEY, value)
            val verified = success && read(context) == value
            if (verified) {
                when (value) {
                    ON_120 -> remember(context, 120)
                    ON_144 -> remember(context, 144)
                }
                FrameAutoOff.onConfirmedWrite(context, value)
            }
            verified
        } catch (_: Exception) { false }
    }
}
