package com.xyrdon.framecontrol

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.PI
import kotlin.math.sin

/**
 * Lightweight, self-drawn, animated indicator. The parent row handles clicks.
 * Only invalidates during a ~280ms transition, never runs a permanent animation.
 */
class AnimatedFpsSwitch @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bounds = RectF()
    private var progress = 0f
    private var animator: ValueAnimator? = null

    private val offTrack = Color.rgb(31, 43, 36)
    private val onTrack = Color.rgb(101, 220, 150)
    private val offOutline = Color.rgb(65, 83, 70)
    private val onOutline = Color.rgb(159, 249, 194)
    private val offThumb = Color.rgb(223, 235, 226)
    private val onThumb = Color.rgb(9, 39, 23)

    fun setEnabledState(enabled: Boolean, animated: Boolean) {
        val destination = if (enabled) 1f else 0f
        if (progress == destination && animator?.isRunning != true) return
        animator?.cancel()
        if (!animated || !isAttachedToWindow) {
            progress = destination
            invalidate()
            return
        }
        animator = ValueAnimator.ofFloat(progress, destination).apply {
            duration = 285L
            interpolator = DecelerateInterpolator(1.8f)
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val density = resources.displayMetrics.density
        val margin = 1.2f * density
        val blend = progress.coerceIn(0f, 1f)
        val round = h / 2f
        bounds.set(margin, margin, w - margin, h - margin)

        p.style = Paint.Style.FILL
        p.color = blendColor(offTrack, onTrack, blend)
        p.shader = if (blend > 0.001f) LinearGradient(
            0f, 0f, w, h,
            blendColor(offTrack, Color.rgb(63, 185, 117), blend),
            blendColor(offTrack, Color.rgb(137, 245, 171), blend),
            Shader.TileMode.CLAMP
        ) else null
        canvas.drawRoundRect(bounds, round, round, p)
        p.shader = null

        p.color = blendColor(offOutline, onOutline, blend)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * density
        canvas.drawRoundRect(bounds, round, round, p)
        p.style = Paint.Style.FILL

        val radius = (h / 2f - 5f * density).coerceAtLeast(1f)
        val left = margin + 4f * density + radius
        val right = w - margin - 4f * density - radius
        val x = left + (right - left) * blend
        val cy = h / 2f
        val pop = 1f + 0.085f * sin(PI.toFloat() * blend)
        p.color = blendColor(offThumb, onThumb, blend)
        canvas.drawCircle(x, cy, radius * pop, p)

        // Small symbol is inside the thumb: a dash when OFF, a check when ON.
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = 2f * density
        val markColor = blendColor(Color.rgb(91, 107, 96), Color.rgb(181, 255, 207), blend)
        p.color = markColor
        if (blend < 0.5f) {
            canvas.drawLine(x - 3.7f * density, cy, x + 3.7f * density, cy, p)
        } else {
            canvas.drawLine(x - 4.4f * density, cy, x - 1f * density, cy + 3f * density, p)
            canvas.drawLine(x - 1f * density, cy + 3f * density, x + 5f * density, cy - 4f * density, p)
        }
        p.style = Paint.Style.FILL
    }

    private fun blendColor(a: Int, b: Int, t: Float): Int = Color.argb(
        lerp(Color.alpha(a), Color.alpha(b), t),
        lerp(Color.red(a), Color.red(b), t),
        lerp(Color.green(a), Color.green(b), t),
        lerp(Color.blue(a), Color.blue(b), t)
    )

    private fun lerp(start: Int, end: Int, t: Float): Int = (start + (end - start) * t).toInt()

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }
}
