package com.xyrdon.framecontrol

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.provider.Settings

/** Low-overhead one-shot session timer. No continuously running service. */
object FrameAutoOff {
    private const val PREF_MINUTES = "auto_off_minutes"
    private const val PREF_END_WALL = "auto_off_end_wall"
    private const val PREF_EXPECTED = "auto_off_expected_value"
    private const val ACTION = "com.xyrdon.framecontrol.AUTO_OFF"

    private fun prefs(context: Context) =
        context.getSharedPreferences(FrameControlSettings.PREFS, Context.MODE_PRIVATE)

    fun selectedMinutes(context: Context): Int = prefs(context).getInt(PREF_MINUTES, 0)
    fun deadline(context: Context): Long = prefs(context).getLong(PREF_END_WALL, 0L)
    fun expectedMode(context: Context): String? = prefs(context).getString(PREF_EXPECTED, null)

    fun choose(context: Context, minutes: Int) {
        if (minutes !in setOf(0, 15, 30, 60, 120)) return
        prefs(context).edit().putInt(PREF_MINUTES, minutes).apply()
        if (minutes == 0) cancel(context) else {
            val current = FrameControlSettings.read(context)
            if (current == FrameControlSettings.ON_120 || current == FrameControlSettings.ON_144) {
                start(context, current, minutes)
            } else cancel(context)
        }
    }

    fun onConfirmedWrite(context: Context, value: String) {
        if (value == FrameControlSettings.ON_120 || value == FrameControlSettings.ON_144) {
            start(context, value, selectedMinutes(context))
        } else cancel(context)
    }

    private fun manager(context: Context): AlarmManager =
        context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun pending(context: Context): PendingIntent {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getBroadcast(context, 776,
            Intent(context, FrameAutoOffReceiver::class.java).setAction(ACTION), flags)
    }

    private fun cancelAlarm(context: Context) {
        try { manager(context).cancel(pending(context)) } catch (_: Exception) {}
    }

    fun cancel(context: Context) {
        cancelAlarm(context)
        prefs(context).edit().remove(PREF_END_WALL).remove(PREF_EXPECTED).apply()
    }

    private fun start(context: Context, value: String, minutes: Int) {
        cancelAlarm(context)
        if (minutes <= 0) {
            prefs(context).edit().remove(PREF_END_WALL).remove(PREF_EXPECTED).apply()
            return
        }
        val duration = minutes * 60_000L
        val endWall = System.currentTimeMillis() + duration
        prefs(context).edit().putLong(PREF_END_WALL, endWall)
            .putString(PREF_EXPECTED, value).commit()
        schedule(context, duration)
    }

    private fun schedule(context: Context, delayMs: Long) {
        val alarm = manager(context)
        val at = SystemClock.elapsedRealtime() + delayMs.coerceAtLeast(1L)
        val intent = pending(context)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) {
                alarm.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, intent)
            } else {
                alarm.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, intent)
            }
        } catch (_: SecurityException) {
            // Some Android/OriginOS versions restrict exact alarms. Fall back to an inexact alarm.
            alarm.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, intent)
        }
    }

    /** Skip stale alarms and never overwrite a mode changed outside Frame Control. */
    fun onTimer(context: Context) {
        val end = deadline(context)
        val expected = expectedMode(context)
        if (end <= 0L || expected == null) return
        val left = end - System.currentTimeMillis()
        if (left > 2000L) {
            schedule(context, left) // Alarm was delivered early or device clock changed.
            return
        }
        val current = FrameControlSettings.read(context)
        if (current == expected && FrameControlSettings.canWrite(context)) {
            try {
                val updated = Settings.System.putString(context.contentResolver,
                    FrameControlSettings.KEY, FrameControlSettings.OFF)
                if (updated) FrameControlSettings.updateQuickTile(context)
            } catch (_: Exception) { }
        }
        cancel(context)
    }

    /** A reboot clears Android alarms, so restore a pending one if allowed by the device. */
    fun onBoot(context: Context) {
        val end = deadline(context)
        val expected = expectedMode(context)
        if (end <= 0 || expected == null) return
        val current = FrameControlSettings.read(context)
        if (current != expected) { cancel(context); return }
        val left = end - System.currentTimeMillis()
        if (left <= 0) onTimer(context) else schedule(context, left)
    }
}

class FrameAutoOffReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == "com.xyrdon.framecontrol.AUTO_OFF") FrameAutoOff.onTimer(context)
    }
}

class FrameBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) FrameAutoOff.onBoot(context)
    }
}
