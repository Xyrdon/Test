package com.xyrdon.framecontrol

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.util.Log

/**
 * A persisted single-session countdown with two independent ways to execute it:
 * an Android AlarmManager wakeup alarm and a lightweight foreground countdown service.
 * In addition, the activity reconciles expired deadlines when opened again.
 */
object FrameAutoOff {
    private const val PREF_MINUTES = "auto_off_minutes"
    private const val PREF_END_WALL = "auto_off_end_wall"
    private const val PREF_EXPECTED = "auto_off_expected_value"
    private const val PREF_ERROR = "auto_off_error"
    private const val PREF_COMPLETED = "auto_off_completed"
    const val ACTION_FIRE = "com.xyrdon.framecontrol.AUTO_OFF"
    const val ACTION_CANCEL = "com.xyrdon.framecontrol.CANCEL_AUTO_OFF"

    private fun prefs(context: Context) =
        context.getSharedPreferences(FrameControlSettings.PREFS, Context.MODE_PRIVATE)

    fun selectedMinutes(context: Context): Int = prefs(context).getInt(PREF_MINUTES, 0)
    fun deadline(context: Context): Long = prefs(context).getLong(PREF_END_WALL, 0L)
    fun expectedMode(context: Context): String? = prefs(context).getString(PREF_EXPECTED, null)
    fun lastError(context: Context): String? = prefs(context).getString(PREF_ERROR, null)
    fun wasCompleted(context: Context): Boolean = prefs(context).getBoolean(PREF_COMPLETED, false)

    fun choose(context: Context, minutes: Int) {
        if (minutes !in setOf(0, 15, 30, 60, 120)) return
        prefs(context).edit().putInt(PREF_MINUTES, minutes).remove(PREF_ERROR)
            .putBoolean(PREF_COMPLETED, false).apply()
        if (minutes == 0) {
            cancel(context)
            return
        }
        val current = FrameControlSettings.read(context)
        if (FrameControlSettings.isActive(current)) {
            start(context, current, minutes)
        } else {
            cancel(context)
        }
    }

    fun onConfirmedWrite(context: Context, value: String) {
        if (FrameControlSettings.isActive(value)) {
            start(context, value, selectedMinutes(context))
        } else {
            cancel(context)
            prefs(context).edit().putBoolean(PREF_COMPLETED, false).apply()
        }
    }

    private fun manager(context: Context): AlarmManager =
        context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun pending(context: Context): PendingIntent {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getBroadcast(
            context, 776,
            Intent(context, FrameAutoOffReceiver::class.java).setAction(ACTION_FIRE), flags
        )
    }

    private fun cancelAlarm(context: Context) {
        try { manager(context).cancel(pending(context)) }
        catch (error: Exception) { Log.w("FrameControl", "Cannot cancel auto-off alarm", error) }
    }

    fun cancel(context: Context) {
        cancelAlarm(context)
        prefs(context).edit().remove(PREF_END_WALL).remove(PREF_EXPECTED).apply()
        try { context.stopService(Intent(context, FrameTimerService::class.java)) }
        catch (error: Exception) { Log.w("FrameControl", "Cannot stop timer service", error) }
    }

    private fun start(context: Context, value: String, minutes: Int) {
        cancelAlarm(context)
        if (minutes <= 0) {
            cancel(context)
            return
        }
        val duration = minutes * 60_000L
        val endWall = System.currentTimeMillis() + duration
        prefs(context).edit()
            .putLong(PREF_END_WALL, endWall)
            .putString(PREF_EXPECTED, value)
            .remove(PREF_ERROR)
            .putBoolean(PREF_COMPLETED, false)
            .commit()
        schedule(context, duration)
        launchService(context)
    }

    private fun schedule(context: Context, delayMs: Long) {
        val alarm = manager(context)
        val at = SystemClock.elapsedRealtime() + delayMs.coerceAtLeast(1L)
        val intent = pending(context)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) {
                alarm.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, intent)
            } else {
                alarm.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, intent)
            }
        } catch (error: SecurityException) {
            // An inexact fallback is better than silently losing the countdown.
            Log.w("FrameControl", "Exact alarm unavailable; using inexact fallback", error)
            try {
                alarm.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, intent)
            } catch (fallback: Exception) {
                Log.e("FrameControl", "Unable to schedule alarm", fallback)
            }
        } catch (error: Exception) {
            Log.e("FrameControl", "Unable to schedule alarm", error)
        }
    }

    private fun launchService(context: Context) {
        try {
            val service = Intent(context, FrameTimerService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service)
            else context.startService(service)
        } catch (error: Exception) {
            // For example, OEM restrictions on starting a foreground service from Quick Settings.
            // The AlarmManager alarm plus activity reconciliation remain available.
            Log.w("FrameControl", "Timer service could not start", error)
        }
    }

    /** The OEM may suppress or remove background alarms. Enforce overdue timers on next app open. */
    fun reconcile(context: Context) {
        val end = deadline(context)
        if (end > 0L && end <= System.currentTimeMillis()) onTimer(context)
    }

    /** Do not overwrite a setting that was changed elsewhere after countdown creation. */
    fun onTimer(context: Context) {
        val end = deadline(context)
        val expected = expectedMode(context)
        if (end <= 0L || expected == null) return
        val left = end - System.currentTimeMillis()
        if (left > 1500L) {
            schedule(context, left)
            return
        }
        val current = FrameControlSettings.read(context)
        var error: String? = null
        var completed = false
        if (current == expected) {
            if (FrameControlSettings.canWrite(context)) {
                try {
                    val success = Settings.System.putString(
                        context.contentResolver, FrameControlSettings.KEY, FrameControlSettings.OFF
                    )
                    if (success && FrameControlSettings.read(context) == FrameControlSettings.OFF) {
                        FrameControlSettings.updateQuickTile(context)
                        completed = true
                    } else {
                        error = "Не удалось выключить: OriginOS не подтвердила изменение"
                    }
                } catch (exception: Exception) {
                    error = "Не удалось выключить: ошибка системной настройки"
                    Log.e("FrameControl", "Auto-off write failed", exception)
                }
            } else {
                error = "Не удалось выключить: нет разрешения на изменение настроек"
            }
        }
        cancel(context)
        if (error != null) {
            prefs(context).edit().putString(PREF_ERROR, error)
                .putBoolean(PREF_COMPLETED, false).apply()
            Log.w("FrameControl", error)
        } else if (completed) {
            prefs(context).edit().remove(PREF_ERROR)
                .putBoolean(PREF_COMPLETED, true).apply()
        }
    }

    /** Android discards elapsed-realtime alarms at reboot; restore the session. */
    fun onBoot(context: Context) {
        val end = deadline(context)
        val expected = expectedMode(context)
        if (end <= 0L || expected == null) return
        val current = FrameControlSettings.read(context)
        if (current != expected) { cancel(context); return }
        val left = end - System.currentTimeMillis()
        if (left <= 0L) onTimer(context) else {
            schedule(context, left)
            launchService(context)
        }
    }
}

class FrameAutoOffReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            FrameAutoOff.ACTION_FIRE -> FrameAutoOff.onTimer(context)
            FrameAutoOff.ACTION_CANCEL -> FrameAutoOff.choose(context, 0)
        }
    }
}

class FrameBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) FrameAutoOff.onBoot(context)
    }
}
