package com.xyrdon.framecontrol

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Choreographer overlay, similar in concept to Vivo/IQOO FPS Unlocker.
 * Counts THIS app's Choreographer callbacks, not the target game's GPU frames.
 * No MediaProjection, screen capture, root, Shizuku or network access.
 */
class FpsOverlayService : Service() {
    companion object {
        const val ACTION_START = "com.xyrdon.framecontrol.START_MONITOR"
        const val ACTION_STOP = "com.xyrdon.framecontrol.STOP_MONITOR"
        private const val CHANNEL = "framecontrol_fps_overlay_v21"
        private const val NOTIFICATION_ID = 42
        @Volatile var isActive: Boolean = false
            private set
    }

    private var windowManager: WindowManager? = null
    private var label: TextView? = null
    private var choreographer: Choreographer? = null
    private var firstFrameNs = 0L
    private var count = 0
    private var displayedFps: Int? = null
    private var lastTextTimeNs = 0L
    private var running = false

    private val callback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            if (firstFrameNs == 0L) {
                firstFrameNs = frameTimeNanos
                lastTextTimeNs = frameTimeNanos
            } else {
                count++
                val elapsed = frameTimeNanos - firstFrameNs
                if (elapsed >= 1_000_000_000L) {
                    displayedFps = (count * 1_000_000_000.0 / elapsed).roundToInt()
                    firstFrameNs = frameTimeNanos
                    count = 0
                }
                if (frameTimeNanos - lastTextTimeNs >= 500_000_000L) {
                    lastTextTimeNs = frameTimeNanos
                    label?.text = "FPS: ${displayedFps ?: "—"}"
                }
            }
            choreographer?.postFrameCallback(this)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action != ACTION_START || running) return START_NOT_STICKY
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startNotification()
            showOverlay()
            running = true
            isActive = true
            firstFrameNs = 0L
            count = 0
            displayedFps = null
            choreographer = Choreographer.getInstance()
            choreographer?.postFrameCallback(callback)
        } catch (error: Exception) {
            Log.e("FrameControl", "Could not start FPS overlay", error)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startNotification() {
        val notifications = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            notifications.createNotificationChannel(
                NotificationChannel(CHANNEL, "Frame Control · FPS", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), pendingFlags
        )
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, FpsOverlayService::class.java).setAction(ACTION_STOP), pendingFlags
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL)
        } else {
            Notification.Builder(this)
        }
        val notification = builder
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Frame Control · FPS")
            .setContentText("Плавающий счётчик включён")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Остановить", stopIntent)
            .build()
        startForeground(NOTIFICATION_ID, notification)
    }

    private fun dp(value: Int): Int = (resources.displayMetrics.density * value).roundToInt()

    private fun showOverlay() {
        val manager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = manager
        val view = TextView(this).apply {
            text = "FPS: —"
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(dp(9), dp(5), dp(9), dp(5))
            background = GradientDrawable().apply {
                setColor(Color.argb(168, 0, 0, 0))
                cornerRadius = dp(9).toFloat()
            }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(10)
            y = dp(84)
        }
        var touchStartX = 0f
        var touchStartY = 0f
        var baseX = 0
        var baseY = 0
        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    touchStartX = event.rawX
                    touchStartY = event.rawY
                    baseX = params.x
                    baseY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = max(0, baseX + (event.rawX - touchStartX).roundToInt())
                    params.y = max(0, baseY + (event.rawY - touchStartY).roundToInt())
                    try { manager.updateViewLayout(view, params) } catch (_: Exception) { }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
        manager.addView(view, params)
        label = view
    }

    override fun onDestroy() {
        running = false
        isActive = false
        choreographer?.removeFrameCallback(callback)
        choreographer = null
        label?.let { view ->
            try { windowManager?.removeView(view) } catch (_: Exception) { }
        }
        label = null
        windowManager = null
        stopForeground(true)
        super.onDestroy()
    }
}
