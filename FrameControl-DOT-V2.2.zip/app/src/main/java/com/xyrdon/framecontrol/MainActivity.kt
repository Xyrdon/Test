package com.xyrdon.framecontrol

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * DOT minimal UI for the working Frame Control switch and Choreographer overlay.
 * The system setting and value strings have not changed from v2.1.
 */
class MainActivity : Activity() {
    private companion object {
        const val SETTING_KEY = "gamecube_frame_interpolation_for_sr"
        const val ON_VALUE = "1:1:0:60:120"
        const val OFF_VALUE = "0:-1:0:0:0"

        const val COLOR_ON = 0xFFA1F7C6.toInt()
        const val COLOR_OFF = 0xFF737C76.toInt()
        const val COLOR_MODE_ON_BG = 0xFF101D17.toInt()
        const val COLOR_MODE_OFF_BG = 0xFF111313.toInt()
    }

    private lateinit var dotCircle: FrameLayout
    private lateinit var powerIcon: ImageView
    private lateinit var modeLabel: TextView
    private lateinit var fpsToggle: TextView
    private lateinit var fpsPanel: LinearLayout
    private var lastSetting: String? = null

    private val handler = Handler(Looper.getMainLooper())
    private val statusPoll = object : Runnable {
        override fun run() {
            refreshMonitorStatus()
            handler.postDelayed(this, 1200L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dotCircle = findViewById(R.id.dotCircle)
        powerIcon = findViewById(R.id.powerIcon)
        modeLabel = findViewById(R.id.modeText)
        fpsToggle = findViewById(R.id.overlayToggle)
        fpsPanel = findViewById(R.id.overlayPanel)

        dotCircle.setOnClickListener { toggleInterpolation() }
        fpsToggle.setOnClickListener { toggleOverlay() }
        fpsPanel.setOnClickListener { toggleOverlay() }

        refreshInterpolation()
        refreshMonitorStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::modeLabel.isInitialized) refreshInterpolation()
        handler.removeCallbacks(statusPoll)
        handler.post(statusPoll)
    }

    override fun onPause() {
        handler.removeCallbacks(statusPoll)
        super.onPause()
    }

    private fun dp(value: Int): Int = (resources.displayMetrics.density * value + .5f).toInt()

    private fun circleBackground(enabled: Boolean): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(if (enabled) COLOR_MODE_ON_BG else COLOR_MODE_OFF_BG)
        setStroke(dp(2), if (enabled) 0xFF78DCAA.toInt() else 0xFF444A47.toInt())
    }

    private fun toggleBackground(enabled: Boolean): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(30).toFloat()
        setColor(if (enabled) 0xFF8DE7B0.toInt() else 0xFF303C34.toInt())
    }

    private fun canWriteSystemSettings(): Boolean = try {
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.System.canWrite(this)
    } catch (_: Exception) {
        false
    }

    private fun refreshInterpolation() {
        try {
            lastSetting = Settings.System.getString(contentResolver, SETTING_KEY)
            val enabled = lastSetting == ON_VALUE
            dotCircle.background = circleBackground(enabled)
            powerIcon.imageTintList = ColorStateList.valueOf(if (enabled) COLOR_ON else COLOR_OFF)
            modeLabel.text = when (lastSetting) {
                ON_VALUE -> "Включено"
                OFF_VALUE -> "Выключено"
                else -> "Неизвестный режим"
            }
            modeLabel.setTextColor(if (enabled) 0xFF8BCFA5.toInt() else 0xFF878D89.toInt())
            dotCircle.contentDescription = if (enabled) {
                "120 FPS включено. Нажми, чтобы выключить"
            } else {
                "120 FPS выключено. Нажми, чтобы включить"
            }
        } catch (error: Exception) {
            lastSetting = null
            dotCircle.background = circleBackground(false)
            powerIcon.imageTintList = ColorStateList.valueOf(COLOR_OFF)
            modeLabel.text = "Ошибка чтения"
            modeLabel.setTextColor(COLOR_OFF)
        }
    }

    private fun toggleInterpolation() {
        if (!canWriteSystemSettings()) {
            Toast.makeText(this, "Разреши изменение системных настроек", Toast.LENGTH_LONG).show()
            openWriteSettings()
            return
        }

        val target = if (lastSetting == ON_VALUE) OFF_VALUE else ON_VALUE
        try {
            val success = Settings.System.putString(contentResolver, SETTING_KEY, target)
            refreshInterpolation()
            if (!success || lastSetting != target) {
                Toast.makeText(this, "Android не подтвердил изменение параметра", Toast.LENGTH_LONG).show()
            }
        } catch (error: Exception) {
            refreshInterpolation()
            Toast.makeText(
                this,
                "Ошибка записи: ${error.message ?: error.javaClass.simpleName}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun refreshMonitorStatus() {
        if (!::fpsToggle.isInitialized) return
        val enabled = FpsOverlayService.isActive
        fpsToggle.text = if (enabled) "ON" else "OFF"
        fpsToggle.setTextColor(if (enabled) 0xFF092112.toInt() else 0xFFC0C8C2.toInt())
        fpsToggle.background = toggleBackground(enabled)
        fpsToggle.contentDescription = if (enabled) {
            "Счётчик FPS включён. Нажми для выключения"
        } else {
            "Счётчик FPS выключен. Нажми для включения"
        }
    }

    private fun toggleOverlay() {
        if (FpsOverlayService.isActive) {
            stopService(Intent(this, FpsOverlayService::class.java))
            handler.postDelayed({ refreshMonitorStatus() }, 250L)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши отображение поверх других приложений", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: ActivityNotFoundException) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            }
            return
        }
        try {
            val start = Intent(this, FpsOverlayService::class.java)
                .setAction(FpsOverlayService.ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(start) else startService(start)
            handler.postDelayed({ refreshMonitorStatus() }, 500L)
        } catch (error: Exception) {
            Toast.makeText(
                this,
                "Не удалось включить счётчик: ${error.message ?: error.javaClass.simpleName}",
                Toast.LENGTH_LONG
            ).show()
            refreshMonitorStatus()
        }
    }

    private fun openWriteSettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        } catch (_: ActivityNotFoundException) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(this, "Открой разрешения приложения в настройках", Toast.LENGTH_LONG).show()
            }
        }
    }
}
