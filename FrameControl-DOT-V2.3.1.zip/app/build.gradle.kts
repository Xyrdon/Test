plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.xyrdon.framecontrol"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.xyrdon.framecontrol"
        minSdk = 26
        targetSdk = 22
        versionCode = 7
        versionName = "2.3.1-dot"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
