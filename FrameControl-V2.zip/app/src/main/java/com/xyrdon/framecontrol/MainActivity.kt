package com.xyrdon.framecontrol

import android.app.Activity
import android.app.ActivityManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private companion object {
        const val SETTING_KEY = "gamecube_frame_interpolation_for_sr"
        const val ON_VALUE = "1:1:0:60:120"
        const val OFF_VALUE = "0:-1:0:0:0"
        const val SCREEN_SHARE_REQUEST = 1042
    }

    private lateinit var toggleButton: Button
    private lateinit var modeText: TextView
    private lateinit var rawValueText: TextView
    private lateinit var feedbackText: TextView
    private lateinit var overlayButton: Button
    private lateinit var monitorStatus: TextView
    private lateinit var permissionBox: View
    private var lastSetting: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val updateOverlay = object : Runnable {
        override fun run() {
            if (::overlayButton.isInitialized) showMonitorStatus()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        toggleButton = findViewById(R.id.toggleButton)
        modeText = findViewById(R.id.modeText)
        rawValueText = findViewById(R.id.rawValueText)
        feedbackText = findViewById(R.id.feedbackText)
        overlayButton = findViewById(R.id.overlayButton)
        monitorStatus = findViewById(R.id.monitorStatus)
        permissionBox = findViewById(R.id.permissionBox)
        toggleButton.setOnClickListener { toggleInterpolation() }
        overlayButton.setOnClickListener { toggleMonitor() }
        findViewById<Button>(R.id.grantButton).setOnClickListener { openWriteSettings() }
        refreshInterpolation()
        showMonitorStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::modeText.isInitialized) refreshInterpolation()
        handler.removeCallbacks(updateOverlay)
        handler.post(updateOverlay)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(updateOverlay)
    }

    private fun canWrite(): Boolean = try { Settings.System.canWrite(this) } catch (_: Exception) { false }

    private fun refreshInterpolation() {
        val allowed = canWrite()
        permissionBox.visibility = if (allowed) View.GONE else View.VISIBLE
        toggleButton.isEnabled = allowed
        toggleButton.alpha = if (allowed) 1f else .5f
        try {
            lastSetting = Settings.System.getString(contentResolver, SETTING_KEY)
            rawValueText.text = lastSetting ?: "Параметр пока отсутствует"
            when (lastSetting) {
                ON_VALUE -> {
                    modeText.text = "РЕЖИМ ВКЛЮЧЁН"
                    toggleButton.text = "Выключить 120 FPS"
                }
                OFF_VALUE -> {
                    modeText.text = "РЕЖИМ ВЫКЛЮЧЕН"
                    toggleButton.text = "Включить 120 FPS"
                }
                else -> {
                    modeText.text = "НЕИЗВЕСТНЫЙ РЕЖИМ"
                    toggleButton.text = "Включить 120 FPS"
                }
            }
        } catch (e: Exception) {
            lastSetting = null
            modeText.text = "ОШИБКА ЧТЕНИЯ"
            toggleButton.isEnabled = false
            feedbackText.text = e.message ?: "Не удалось прочитать системный параметр"
        }
    }

    private fun toggleInterpolation() {
        if (!canWrite()) { openWriteSettings(); return }
        val desired = if (lastSetting == ON_VALUE) OFF_VALUE else ON_VALUE
        try {
            val wrote = Settings.System.putString(contentResolver, SETTING_KEY, desired)
            refreshInterpolation()
            feedbackText.text = if (wrote && lastSetting == desired) {
                "Параметр сохранён и проверен."
            } else {
                "Система не подтвердила запись. Фактический режим не гарантирован."
            }
        } catch (e: Exception) {
            feedbackText.text = "Ошибка записи: ${e.message ?: e.javaClass.simpleName}"
            refreshInterpolation()
        }
    }

    private fun showMonitorStatus() {
        val running = isMonitorRunning()
        overlayButton.text = if (running) "OFF" else "ON"
        monitorStatus.text = if (running) "Мониторинг включён · ≈ FPS" else "Плавающий счётчик выключен"
    }

    @Suppress("DEPRECATION")
    private fun isMonitorRunning(): Boolean {
        // Running flag lives in the same app process as the service.
        return FpsOverlayService.isActive
    }

    private fun toggleMonitor() {
        if (isMonitorRunning()) {
            startService(Intent(this, FpsOverlayService::class.java).setAction(FpsOverlayService.ACTION_STOP))
            handler.postDelayed({ showMonitorStatus() }, 250L)
            return
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши отображение поверх других приложений, затем нажми ON", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            }
            return
        }
        // A system dialog asks permission to capture the screen on each launch.
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), SCREEN_SHARE_REQUEST)
    }

    @Deprecated("Legacy Activity result API keeps this sample dependency-free")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != SCREEN_SHARE_REQUEST) return
        if (resultCode != RESULT_OK || data == null) {
            feedbackText.text = "Доступ к демонстрации экрана не предоставлен."
            return
        }
        val intent = Intent(this, FpsOverlayService::class.java).apply {
            action = FpsOverlayService.ACTION_START
            putExtra(FpsOverlayService.EXTRA_RESULT_CODE, resultCode)
            putExtra(FpsOverlayService.EXTRA_PROJECTION_DATA, data)
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            feedbackText.text = "Мониторинг запускается. Открой игру для проверки."
            handler.postDelayed({ showMonitorStatus() }, 1200L)
        } catch (e: Exception) {
            feedbackText.text = "Не удалось запустить мониторинг: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun openWriteSettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        } catch (_: ActivityNotFoundException) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS))
        }
    }
}
