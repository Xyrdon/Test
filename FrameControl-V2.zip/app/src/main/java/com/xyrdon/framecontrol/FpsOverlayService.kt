package com.xyrdon.framecontrol

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import java.util.ArrayDeque
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * FPS experiment based on changes in captured screen images (not SurfaceFlinger stats).
 * No network, storage, audio capture, root, Shizuku, or private APIs.
 * Result is an approximation of distinct visible screen images, NOT guaranteed game FPS.
 */
class FpsOverlayService : Service() {
    companion object {
        const val ACTION_START = "com.xyrdon.framecontrol.START_MONITOR"
        const val ACTION_STOP = "com.xyrdon.framecontrol.STOP_MONITOR"
        const val EXTRA_RESULT_CODE = "projectionResultCode"
        const val EXTRA_PROJECTION_DATA = "projectionData"
        private const val CHANNEL = "fps_capture_channel"
        private const val NOTIFICATION_ID = 42
        @Volatile var isActive: Boolean = false
            private set
    }

    private lateinit var windowManager: WindowManager
    private lateinit var bubble: TextView
    private var windowParams: WindowManager.LayoutParams? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var worker: Handler? = null
    private val ui = Handler(Looper.getMainLooper())
    private val recentChanges = ArrayDeque<Long>()
    private var previousSample: IntArray? = null
    private var totalFrames = 0
    private var stopping = false
    private var lastFramesAt = 0L

    private val updateText = object : Runnable {
        override fun run() {
            worker?.post {
                val now = SystemClock.elapsedRealtimeNanos()
                pruneChanges(now)
                val fps = recentChanges.size
                ui.post {
                    if (!stopping) bubble.text = when {
                        totalFrames < 4 -> "≈ FPS  —"
                        lastFramesAt != 0L && now - lastFramesAt > 1_500_000_000L -> "≈ FPS  —"
                        else -> "≈ FPS  $fps"
                    }
                }
            }
            if (!stopping) ui.postDelayed(this, 500L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action != ACTION_START) return START_NOT_STICKY
        if (isActive) return START_NOT_STICKY
        try {
            startCaptureNotification()
            val captureData: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(EXTRA_PROJECTION_DATA)
            }
            requireNotNull(captureData) { "Отсутствует разрешение на захват экрана" }
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, captureData)
            requireNotNull(projection) { "Android отказал в MediaProjection" }
            projection!!.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { ui.post { stopSelf() } }
                override fun onCapturedContentResize(width: Int, height: Int) {
                    worker?.post { changeCaptureSize(width, height) }
                }
            }, ui)
            workerThread = HandlerThread("fps-analysis").also { it.start() }
            worker = Handler(workerThread!!.looper)
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            createBubble()
            val metrics = resources.displayMetrics
            worker?.post { setupCapture(metrics.widthPixels, metrics.heightPixels, metrics.densityDpi) }
            isActive = true
            ui.post(updateText)
        } catch (e: Exception) {
            android.util.Log.e("FrameControl", "Не удалось запустить мониторинг", e)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCaptureNotification() {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            notificationManager.createNotificationChannel(
                NotificationChannel(CHANNEL, "Frame Control · FPS", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, FpsOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val notification = builder
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Frame Control · ≈ FPS")
            .setContentText("Анализ изображения экрана. Нажми, чтобы открыть приложение.")
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Остановить", stopIntent)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private fun createBubble() {
        bubble = TextView(this).apply {
            text = "≈ FPS  —"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.argb(226, 10, 10, 12))
                cornerRadius = dp(13).toFloat()
                setStroke(dp(1), Color.rgb(58, 58, 64))
            }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(95)
        }
        windowParams = params
        var startTouchX = 0f
        var startTouchY = 0f
        var startWindowX = 0
        var startWindowY = 0
        bubble.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startTouchX = event.rawX
                    startTouchY = event.rawY
                    startWindowX = params.x
                    startWindowY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = max(0, startWindowX + (event.rawX - startTouchX).roundToInt())
                    params.y = max(0, startWindowY + (event.rawY - startTouchY).roundToInt())
                    try { windowManager.updateViewLayout(bubble, params) } catch (_: Exception) { }
                    true
                }
                else -> true
            }
        }
        windowManager.addView(bubble, params)
    }

    private fun captureDimensions(width: Int, height: Int): Pair<Int, Int> {
        val longest = max(width, height).coerceAtLeast(1)
        val scale = 640.0 / longest
        return Pair(max(1, (width * scale).roundToInt()), max(1, (height * scale).roundToInt()))
    }

    private fun createReader(width: Int, height: Int): ImageReader {
        val (w, h) = captureDimensions(width, height)
        return ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 4).also { r ->
            r.setOnImageAvailableListener({ imageReader ->
                // Drain the queue rather than silently discarding all but the last frame.
                try {
                    while (true) {
                        val image = imageReader.acquireNextImage() ?: break
                        try { processImage(image) } finally { image.close() }
                    }
                } catch (_: IllegalStateException) { }
            }, worker)
        }
    }

    private fun setupCapture(width: Int, height: Int, densityDpi: Int) {
        if (stopping) return
        try {
            val currentReader = createReader(width, height)
            reader = currentReader
            virtualDisplay = projection?.createVirtualDisplay(
                "FrameControl-visible-frames", currentReader.width, currentReader.height, densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, currentReader.surface, null, worker
            )
        } catch (e: Exception) {
            android.util.Log.e("FrameControl", "Захват экрана не запустился", e)
            ui.post { stopSelf() }
        }
    }

    private fun changeCaptureSize(width: Int, height: Int) {
        if (stopping || width <= 0 || height <= 0 || virtualDisplay == null) return
        try {
            val next = createReader(width, height)
            virtualDisplay!!.resize(next.width, next.height, resources.displayMetrics.densityDpi)
            virtualDisplay!!.setSurface(next.surface)
            reader?.setOnImageAvailableListener(null, null)
            reader?.close()
            reader = next
            previousSample = null
            recentChanges.clear()
        } catch (e: Exception) {
            android.util.Log.w("FrameControl", "Не удалось обновить размер захвата", e)
        }
    }

    private fun processImage(image: Image) {
        if (stopping) return
        val plane = image.planes.firstOrNull() ?: return
        val buffer = plane.buffer
        val w = image.width
        val h = image.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        // Sample a small grid: avoids copying frames / saving screenshots.
        val gridX = 20
        val gridY = 14
        val sample = IntArray(gridX * gridY)
        var i = 0
        for (gy in 0 until gridY) {
            val y = ((gy + .5) * h / gridY).toInt().coerceIn(0, h - 1)
            for (gx in 0 until gridX) {
                val x = ((gx + .5) * w / gridX).toInt().coerceIn(0, w - 1)
                val index = y * rowStride + x * pixelStride
                sample[i++] = if (index >= 0 && index + 3 < buffer.limit()) buffer.getInt(index) else 0
            }
        }
        val old = previousSample
        previousSample = sample
        totalFrames++
        val now = SystemClock.elapsedRealtimeNanos()
        lastFramesAt = now
        if (old != null && old.size == sample.size) {
            var changedPixels = 0
            for (index in sample.indices) {
                val a = old[index]
                val b = sample[index]
                val r = abs((a and 255) - (b and 255))
                val g = abs(((a ushr 8) and 255) - ((b ushr 8) and 255))
                val blue = abs(((a ushr 16) and 255) - ((b ushr 16) and 255))
                if (r + g + blue > 42) changedPixels++
            }
            // Ignore tiny local changes (e.g. floating counter updates or static UI flicker).
            if (changedPixels >= 12) recentChanges.addLast(now)
        }
        pruneChanges(now)
    }

    private fun pruneChanges(now: Long) {
        while (recentChanges.isNotEmpty() && now - recentChanges.peekFirst() > 1_000_000_000L) {
            recentChanges.removeFirst()
        }
    }

    override fun onDestroy() {
        stopping = true
        isActive = false
        ui.removeCallbacks(updateText)
        try { if (::bubble.isInitialized) windowManager.removeView(bubble) } catch (_: Exception) { }
        try { reader?.setOnImageAvailableListener(null, null) } catch (_: Exception) { }
        try { virtualDisplay?.release() } catch (_: Exception) { }
        try { reader?.close() } catch (_: Exception) { }
        try { projection?.stop() } catch (_: Exception) { }
        workerThread?.quitSafely()
        stopForeground(true)
        super.onDestroy()
    }
}
