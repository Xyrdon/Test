plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.xyrdon.framecontrol"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.xyrdon.framecontrol"
        minSdk = 26
        targetSdk = 22
        versionCode = 2
        versionName = "1.1-legacy-test"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
