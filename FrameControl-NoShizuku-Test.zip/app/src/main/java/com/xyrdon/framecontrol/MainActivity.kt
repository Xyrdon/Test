package com.xyrdon.framecontrol

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.TextView

/**
 * Изменяет только одно значение в Settings.System. Не использует root, Shizuku или ADB.
 * Отдельно проверяет, что значение действительно сохранилось.
 */
class MainActivity : Activity() {

    private companion object {
        const val SETTING_KEY = "gamecube_frame_interpolation_for_sr"
        const val ENABLED_VALUE = "1:1:0:60:120"
        const val DISABLED_VALUE = "0:-1:0:0:0"
    }

    private lateinit var modeText: TextView
    private lateinit var modeDescription: TextView
    private lateinit var rawValueText: TextView
    private lateinit var feedbackText: TextView
    private lateinit var toggleButton: Button
    private lateinit var permissionBox: View

    private var lastValue: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        modeText = findViewById(R.id.modeText)
        modeDescription = findViewById(R.id.modeDescription)
        rawValueText = findViewById(R.id.rawValueText)
        feedbackText = findViewById(R.id.feedbackText)
        toggleButton = findViewById(R.id.toggleButton)
        permissionBox = findViewById(R.id.permissionBox)

        toggleButton.setOnClickListener { toggleValue() }
        findViewById<Button>(R.id.refreshButton).setOnClickListener {
            refreshStatus()
            feedbackText.text = "Значение повторно прочитано из System Table."
        }
        findViewById<Button>(R.id.grantButton).setOnClickListener { openPermissionPage() }

        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::modeText.isInitialized) refreshStatus()
    }

    private fun hasPermission(): Boolean = try {
        Settings.System.canWrite(this)
    } catch (_: Exception) {
        false
    }

    /** Returns null both for an absent setting and failed reads; show an honest fallback. */
    private fun readValue(): String? = Settings.System.getString(contentResolver, SETTING_KEY)

    private fun refreshStatus() {
        val allowed = hasPermission()
        permissionBox.visibility = if (allowed) View.GONE else View.VISIBLE
        toggleButton.isEnabled = allowed
        toggleButton.alpha = if (allowed) 1f else 0.50f

        try {
            val value = readValue()
            lastValue = value
            rawValueText.text = "Текущее значение: ${value ?: "не найдено"}"
            when (value) {
                ENABLED_VALUE -> {
                    modeText.text = "120 FPS · ВКЛ"
                    modeDescription.text = "Значение для интерполяции 120 FPS записано"
                    toggleButton.text = "Выключить 120 FPS"
                }
                DISABLED_VALUE -> {
                    modeText.text = "ВЫКЛЮЧЕНО"
                    modeDescription.text = "Используется значение отключения"
                    toggleButton.text = "Включить 120 FPS"
                }
                else -> {
                    modeText.text = "ДРУГОЙ РЕЖИМ"
                    modeDescription.text = if (value == null)
                        "Параметр отсутствует. Можно попробовать включить 120 FPS."
                    else "Обнаружено значение, отличающееся от двух шаблонов"
                    toggleButton.text = "Включить 120 FPS"
                }
            }
        } catch (e: Exception) {
            lastValue = null
            modeText.text = "ОШИБКА ЧТЕНИЯ"
            modeDescription.text = "Не удалось прочитать System Table"
            rawValueText.text = "Текущее значение: недоступно"
            toggleButton.isEnabled = false
            feedbackText.text = "Ошибка: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun toggleValue() {
        if (!hasPermission()) {
            openPermissionPage()
            return
        }
        val desired = if (lastValue == ENABLED_VALUE) DISABLED_VALUE else ENABLED_VALUE
        try {
            val result = Settings.System.putString(contentResolver, SETTING_KEY, desired)
            refreshStatus()
            val saved = lastValue == desired
            feedbackText.text = when {
                !result -> "Android отказал в записи параметра. Значение не подтверждено."
                saved -> if (desired == ENABLED_VALUE)
                    "Готово: System Table содержит значение 120 FPS. Проверь эффект в игре."
                else "Готово: значение отключения сохранено."
                else -> "Запись выполнена, но проверка не совпала. Возможно, OriginOS отклонила или изменила значение."
            }
        } catch (e: Exception) {
            refreshStatus()
            feedbackText.text = "Не удалось записать параметр: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun openPermissionPage() {
        val appPage = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
            data = Uri.parse("package:$packageName")
        }
        try {
            startActivity(appPage)
        } catch (_: ActivityNotFoundException) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS))
            } catch (e: Exception) {
                feedbackText.text = "Не удалось открыть настройки разрешения: ${e.message ?: e.javaClass.simpleName}"
            }
        } catch (e: Exception) {
            feedbackText.text = "Не удалось открыть настройки разрешения: ${e.message ?: e.javaClass.simpleName}"
        }
    }
}
